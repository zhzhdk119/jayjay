#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Prime 수집 서버 '저절로 낫기'(R-ADV-1120-2325 P0-2). 비밀값 0 · 밖에서 들어오는 접속 0 · 서버 재부팅·삭제 0.

두 곳에서 쓴다.
  ① prime-heal.timer(1분마다, root) →  python3 selfheal.py tick
       - 서비스(prime-collector)가 죽었거나 15분 넘게 아무 기록이 없으면 다시 켬(systemd Restart=always 의 보조)
       - Chrome 이 멈춘 칸(그 칸 Chrome 묶음 CPU 시간이 10분 동안 그대로)만 그 칸 Chrome 을 끔 → 러너가 그 칸만 실패 처리·다음 회차에 다시
       - 디스크 80% 넘으면 우리 폴더의 지난 회차 기록·이전 꾸러미 압축·로그·Chrome 캐시만 정리(로그인 정보·프로필은 그대로)
       - 메모리 90% 넘으면 새 회차를 10분 늦춤(throttle.json) — 도는 회차는 건드리지 않음
       - 하루 1번(KST 날짜가 바뀐 뒤 첫 틱) 자체 점검 → selfcheck.json
       - 지금 상태(CPU·메모리·디스크·오늘 실패 수·다시 로그인 필요 매장) → health.json  (에이전트가 '살아 있음'에 실어 보냄)
  ② agent.py 안(후크 4줄): health_for_hello() · throttled() · after_round() · is_bad_bundle()
       - 코드 업데이트 뒤 회차가 2번 연속 실패하면 이전 꾸러미로 자동 되돌림(bundle_pin.json) — 운영 쪽 '켜진 꾸러미'가 다른 번호로 바뀌면 고정 풂

되돌리기: systemctl disable --now prime-heal.timer (저절로 낫기 전체) · PRIME_HEAL_ROLLBACK=0 (자동 되돌림만) — config.json "heal": {...} 로도 끔.
"""
import json
import os
import shutil
import signal
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

HEAL_VERSION = "2325.1+0116"
KST = timezone(timedelta(hours=9))
VAR = Path(os.environ.get("PRIME_VAR", "/var/lib/prime-collector"))
ETC = Path(os.environ.get("PRIME_ETC", "/etc/prime-collector"))
PROC = Path(os.environ.get("PRIME_PROC", "/proc"))
SERVICE = "prime-collector.service"

DEFAULTS = {
    "disk_pct": 80,            # 넘으면 정리
    "mem_pct": 90,             # 넘으면 새 회차 늦춤
    "throttle_min": 10,
    "hang_min": 10,            # 칸 Chrome CPU 시간이 이만큼 그대로면 멈춤
    "agent_quiet_min": 15,     # 에이전트 기록이 이만큼 없으면 서비스 다시 켬
    "keep_runs": 20,           # 정리 때 남길 최근 회차 기록 수
    "keep_bundles": 3,         # 남길 꾸러미 폴더 수(지금 것 포함)
    "log_max_mb": 20,
    "rollback_after": 2,       # 새 꾸러미에서 연속 실패 n번 → 이전 꾸러미
}


def now_utc():
    return datetime.now(timezone.utc)


def cfg():
    c = dict(DEFAULTS)
    try:
        c.update((json.loads((ETC / "config.json").read_text(encoding="utf-8")).get("heal") or {}))
    except (OSError, ValueError):
        pass
    return c


def _rj(p, default=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _wj(p, obj):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, default=str), encoding="utf-8")
    os.replace(tmp, p)


def hlog(msg):
    line = f"{datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S')} [heal] {msg}"
    print(line, flush=True)
    try:
        VAR.mkdir(parents=True, exist_ok=True)
        with (VAR / "heal.log").open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


# ---------------- 측정 ----------------
def cpu_pct(state):
    """/proc/stat 두 틱 사이 사용률(%). 첫 틱은 None."""
    try:
        f = [int(x) for x in (PROC / "stat").read_text().splitlines()[0].split()[1:]]
    except (OSError, ValueError, IndexError):
        return None
    idle, total = f[3] + (f[4] if len(f) > 4 else 0), sum(f)
    prev = state.get("cpu")
    state["cpu"] = [idle, total]
    if not prev or total <= prev[1]:
        return None
    return round(100.0 * (1 - (idle - prev[0]) / (total - prev[1])), 1)


def mem_pct():
    m = {}
    try:
        for line in (PROC / "meminfo").read_text().splitlines():
            k, v = line.split(":", 1)
            m[k] = int(v.split()[0])
        return round(100.0 * (1 - m["MemAvailable"] / m["MemTotal"]), 1)
    except (OSError, ValueError, KeyError, ZeroDivisionError):
        return None


def disk_pct(path=None):
    try:
        u = shutil.disk_usage(str(path or VAR))
        return round(100.0 * u.used / u.total, 1)
    except OSError:
        return None


# ---------------- 디스크 정리(우리 폴더만) ----------------
CACHE_DIRS = ("Cache", "Code Cache", "GPUCache", "Service Worker/CacheStorage", "ShaderCache", "GrShaderCache")


def _size(p):
    n = 0
    for root, _, files in os.walk(p):
        for f in files:
            try:
                n += os.lstat(os.path.join(root, f)).st_size
            except OSError:
                pass
    return n


def _inside(p, base):
    try:
        Path(p).resolve().relative_to(Path(base).resolve())
        return True
    except ValueError:
        return False


def disk_clean(c):
    """VAR 안만 정리. 지우는 것 = 지난 회차 기록(최근 keep_runs 남김)·이전 꾸러미 압축(.tgz)·오래된 꾸러미 폴더(지금+직전 남김)·
    큰 로그(뒤 1MB 만 남김)·Chrome 캐시 폴더. 지우지 않는 것 = 프로필(로그인 정보)·키·설정·지금/직전 꾸러미."""
    freed, done = 0, []
    var = VAR.resolve()

    def rm(p):
        nonlocal freed
        p = Path(p)
        if not _inside(p, var) or p.resolve() == var:
            return
        try:
            sz = _size(p) if p.is_dir() else p.stat().st_size
            shutil.rmtree(p) if p.is_dir() and not p.is_symlink() else p.unlink()
            freed += sz
        except OSError:
            pass

    runs = VAR / "runs"
    if runs.is_dir():
        old = sorted((p for p in runs.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime, reverse=True)[int(c["keep_runs"]):]
        for p in old:
            rm(p)
        done.append(f"회차 기록 {len(old)}개")
    bdir = VAR / "bundle"
    if bdir.is_dir():
        cur = (bdir / "current").resolve().name if (bdir / "current").exists() else None
        pin = (_rj(VAR / "bundle_pin.json") or {}).get("good")
        keep = {cur, pin}
        for p in bdir.glob("*.tgz"):
            if p.stem not in keep:
                rm(p)
        dirs = sorted((p for p in bdir.iterdir() if p.is_dir() and not p.is_symlink() and not p.name.endswith(".tmp")),
                      key=lambda p: p.stat().st_mtime, reverse=True)
        extra = [p for p in dirs if p.name not in keep][max(0, int(c["keep_bundles"]) - 1):]
        for p in extra:
            rm(p)
        for p in bdir.glob("*.tmp"):
            rm(p)
        done.append(f"이전 꾸러미 {len(extra)}개")
    for lg in list(VAR.glob("*.log")) + list(VAR.glob("*.out")):
        try:
            if lg.stat().st_size > int(c["log_max_mb"]) * 1024 * 1024:
                with lg.open("rb") as f:
                    f.seek(-1024 * 1024, 2)
                    tail = f.read()
                before = lg.stat().st_size
                lg.write_bytes(tail)
                freed += before - len(tail)
                done.append(f"로그 {lg.name}")
        except OSError:
            pass
    # 0116 칸 감시기: 칸 결과 보낸 파일은 칸마다 최근 500개만 · 칸 프로필도 Chrome 캐시만 정리
    sent_n = 0
    for sd in (VAR / "lanes").glob("lane-*/outbox/sent"):
        old = sorted(sd.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[500:]
        for p in old:
            rm(p)
        sent_n += len(old)
    if sent_n:
        done.append(f"칸 결과 보낸 파일 {sent_n}개")
    prof_dirs = [d for d in [VAR / "profiles"] if d.is_dir()] + [d for d in (VAR / "lanes").glob("lane-*/profiles") if d.is_dir()]
    for prof in prof_dirs:
        n = 0
        for pd in prof.iterdir():
            for sub in ("", "Default"):
                for cd in CACHE_DIRS:
                    p = pd / sub / cd if sub else pd / cd
                    if p.is_dir():
                        rm(p)
                        n += 1
        done.append(f"Chrome 캐시 {n}곳")
    return {"freed_mb": round(freed / 1024 / 1024, 1), "done": done}


# ---------------- Chrome 멈춤(칸 단위) ----------------
def _procs():
    """[{pid, ppid, cmd, cpu_ticks, user}] — /proc 에서."""
    out = []
    for d in PROC.iterdir() if PROC.is_dir() else []:
        if not d.name.isdigit():
            continue
        try:
            st = (d / "stat").read_text()
            rest = st[st.rindex(")") + 2:].split()
            cmd = (d / "cmdline").read_bytes().replace(b"\0", b" ").decode("utf-8", "replace").strip()
            out.append({"pid": int(d.name), "ppid": int(rest[1]), "cmd": cmd, "cpu": int(rest[11]) + int(rest[12])})
        except (OSError, ValueError, IndexError):
            continue
    return out


def lane_groups(procs):
    """user-data-dir 가 VAR/profiles/<칸> 인 Chrome 주 프로세스마다, 그 자식들까지 묶어 {칸: {pids, cpu}}."""
    root = (VAR / "profiles").as_posix() + "/"
    lroot = (VAR / "lanes").as_posix() + "/"          # 0116 칸 감시기: lanes/lane-<k>/profiles/store-<id> → 묶음 'lane-<k>/store-<id>'
    kids = {}
    for p in procs:
        kids.setdefault(p["ppid"], []).append(p)
    groups = {}
    for p in procs:
        if "--type=" in p["cmd"] or "chrome" not in p["cmd"].lower():
            continue
        i = p["cmd"].find("--user-data-dir=" + root)
        if i >= 0:
            lane = p["cmd"][i + len("--user-data-dir=" + root):].split()[0].strip('"').split("/")[0]
        else:
            i = p["cmd"].find("--user-data-dir=" + lroot)
            if i < 0:
                continue
            parts = p["cmd"][i + len("--user-data-dir=" + lroot):].split()[0].strip('"').split("/")
            lane = "/".join(x for x in (parts[0], parts[-1] if len(parts) > 1 else "") if x)
        g = groups.setdefault(lane, {"pids": [], "cpu": 0})
        stack = [p]
        while stack:
            q = stack.pop()
            g["pids"].append(q["pid"])
            g["cpu"] += q["cpu"]
            stack.extend(kids.get(q["pid"], []))
    return groups


def chrome_hang(c, state, now_s=None, procs=None, kill=os.kill):
    """칸 Chrome 묶음의 CPU 시간이 hang_min 동안 그대로면 그 칸 묶음만 끔. 원격 로그인 화면(prime screen) 칸은 사람이 쓰는 중이라 제외."""
    now_s = now_s or time.time()
    groups = lane_groups(procs if procs is not None else _procs())
    seen = state.setdefault("lanes", {})
    screen = Path("/run/prime-screen/pids").exists()
    killed = []
    for lane, g in groups.items():
        prev = seen.get(lane)
        if not prev or prev["cpu"] != g["cpu"]:
            seen[lane] = {"cpu": g["cpu"], "since": now_s}
            continue
        if screen and lane.startswith("store-"):
            continue
        if now_s - prev["since"] >= float(c["hang_min"]) * 60:
            for pid in sorted(g["pids"], reverse=True):
                try:
                    kill(pid, getattr(signal, "SIGKILL", 9))
                except OSError:
                    pass
            killed.append(lane)
            seen.pop(lane, None)
            hlog(f"칸 {lane} Chrome 이 {c['hang_min']}분 동안 멈춰 있어 그 칸만 껐어요(다른 칸은 그대로)")
    for lane in list(seen):
        if lane not in groups:
            seen.pop(lane, None)
    return killed


# ---------------- 서비스 ----------------
def _sysctl(*a):
    try:
        return subprocess.run(["systemctl", *a], capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired):
        return None


def service_check(c, now_s=None):
    """죽었으면 다시 켬 · 살아 있는데 agent.log 가 agent_quiet_min 넘게 그대로면(멈춤) 다시 켬. systemd 없는 시험 환경은 '확인만'."""
    now_s = now_s or time.time()
    if not Path("/run/systemd/system").exists():
        return "systemd 없음(시험 환경)"
    r = _sysctl("is-active", SERVICE)
    active = bool(r and r.stdout.strip() == "active")
    if not active:
        _sysctl("restart", SERVICE)
        hlog("수집 서비스가 꺼져 있어 다시 켰어요")
        return "다시 켬(꺼져 있었음)"
    try:
        quiet = now_s - (VAR / "agent.log").stat().st_mtime
    except OSError:
        quiet = 0
    if quiet > float(c["agent_quiet_min"]) * 60:
        _sysctl("restart", SERVICE)
        hlog(f"수집 서비스가 {int(quiet // 60)}분 동안 기록이 없어 다시 켰어요")
        return "다시 켬(멈춤)"
    return "정상"


# ---------------- 메모리 늦춤 ----------------
def throttle_set(c, mem, now_s=None):
    now_s = now_s or time.time()
    if mem is not None and mem >= float(c["mem_pct"]):
        until = now_s + float(c["throttle_min"]) * 60
        _wj(VAR / "throttle.json", {"until": until, "mem_pct": mem})
        hlog(f"메모리 {mem}% — 새 회차를 {c['throttle_min']}분 늦춰요")
        return True
    return False


def throttled(now_s=None):
    """agent 후크: True 면 이번 틱엔 새 회차를 시작하지 않는다(다음 틱에 다시 봄)."""
    t = _rj(VAR / "throttle.json") or {}
    return float(t.get("until") or 0) > (now_s or time.time())


# ---------------- 하루 1번 자체 점검 ----------------
def _cmd_ok(args):
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=60)
        return r.returncode == 0, (r.stdout or r.stderr).strip()[:80]
    except (OSError, subprocess.TimeoutExpired) as e:
        return False, type(e).__name__


def selfcheck(c, now=None):
    now = now or now_utc()
    items = {}
    items["chrome"] = _cmd_ok(["google-chrome", "--version"])
    items["xvfb"] = (shutil.which("Xvfb") is not None, "")
    items["python"] = (True, sys.version.split()[0])
    items["key"] = ((ETC / "host_key.pem").exists() and oct((ETC / "host_key.pem").stat().st_mode & 0o777) == "0o600", "")
    cur = VAR / "bundle" / "current"
    items["bundle"] = (cur.exists(), cur.resolve().name if cur.exists() else "")
    d, m = disk_pct(), mem_pct()
    items["disk"] = (d is not None and d < float(c["disk_pct"]), f"{d}%")
    items["mem"] = (m is not None and m < float(c["mem_pct"]), f"{m}%")
    items["clock"] = _cmd_ok(["timedatectl", "show", "-p", "NTPSynchronized", "--value"]) if shutil.which("timedatectl") else (True, "")
    if items["clock"][1] == "no":
        items["clock"] = (False, "시계 동기화 안 됨")
    ls = _rj(VAR / "lanes" / "status.json")         # 0116: 칸 감시기 쓰는 서버만(없으면 항목 없음)
    if ls:
        alive, n = int(ls.get("alive") or 0), int(ls.get("lanes") or 0)
        live = ls.get("mode") == "loop"
        items["lanes"] = ((alive == n) if live else True,
                          f"칸 {alive}/{n} 살아 있음 · 다시 띄움 {ls.get('restarts', 0)} · Chrome {ls.get('chrome')}")
    bad = [k for k, (ok, _) in items.items() if not ok]
    res = {"day": now.astimezone(KST).strftime("%Y-%m-%d"), "at": now.isoformat(), "ok": not bad, "bad": bad,
           "items": {k: {"ok": ok, "v": v} for k, (ok, v) in items.items()}}
    _wj(VAR / "selfcheck.json", res)
    hlog(f"자체 점검 {res['day']}: {'이상 없음' if not bad else '확인 필요 ' + ','.join(bad)}"
         + (f" · {items['lanes'][1]}" if "lanes" in items else ""))
    return res


# ---------------- 회차 결과 · 자동 되돌림 ----------------
def _day(now=None):
    return (now or now_utc()).astimezone(KST).strftime("%Y-%m-%d")


def after_round(version, ok, per_store=None, now=None, activate=None):
    """agent 후크: 회차가 끝날 때마다. 반환 = 되돌렸으면 안내 문구, 아니면 None.
    - 오늘 실패 수 누적(fail_today), 매장별 로그인 상태(login: ok|relogin) 갱신
    - 새 꾸러미에서 rollback_after 번 연속 실패 → 직전 성공 꾸러미로 current 를 돌리고 그 번호를 고정(bundle_pin.json)"""
    c = cfg()
    st = _rj(VAR / "rounds.json") or {}
    day = _day(now)
    if st.get("day") != day:
        st.update({"day": day, "fail_today": 0, "rounds_today": 0})
    st["rounds_today"] = st.get("rounds_today", 0) + 1
    fails = 0 if ok else 1
    logins = st.get("login") or {}
    for x in per_store or []:
        fails += int(x.get("fail") or 0)
        lg = x.get("login")
        if lg in ("ok", "relogin"):
            logins[str(x.get("store"))] = {"state": lg, "channel": x.get("channel"), "at": (now or now_utc()).isoformat()}
    st["login"] = logins
    st["fail_today"] = st.get("fail_today", 0) + fails
    msg = None
    if ok:
        st["good"] = version
        st["streak"] = {"version": version, "n": 0}
    else:
        s = st.get("streak") or {}
        s = {"version": version, "n": (s.get("n", 0) + 1) if s.get("version") == version else 1}
        st["streak"] = s
        good = st.get("good")
        on = os.environ.get("PRIME_HEAL_ROLLBACK", str(c.get("rollback", "1"))) != "0"
        if on and good and good != version and s["n"] >= int(c["rollback_after"]):
            if (activate or _activate_local)(good):
                _wj(VAR / "bundle_pin.json", {"bad": version, "good": good, "at": (now or now_utc()).isoformat()})
                st["streak"] = {"version": good, "n": 0}
                msg = f"새 코드 {version} 에서 회차가 {s['n']}번 연속 실패해 이전 코드 {good} 로 되돌렸어요"
                st["rollback"] = {"from": version, "to": good, "at": (now or now_utc()).isoformat()}
                hlog(msg)
    _wj(VAR / "rounds.json", st)
    return msg


def _activate_local(ver):
    root = VAR / "bundle"
    if not (root / ver).is_dir():
        return False
    new = root / "current.new"
    if new.is_symlink() or new.exists():
        new.unlink()
    new.symlink_to(ver)
    new.replace(root / "current")
    return True


def is_bad_bundle(active_version):
    """agent 후크(sync_bundle): 운영 쪽 켜진 꾸러미가 되돌린 '나쁜 번호'면 받지 않음. 다른 번호로 바뀌면 고정을 풂."""
    pin = _rj(VAR / "bundle_pin.json")
    if not pin:
        return False
    if active_version == pin.get("bad"):
        return True
    try:
        (VAR / "bundle_pin.json").rename(VAR / f"bundle_pin.released.{int(time.time())}.json")
    except OSError:
        pass
    return False


# ---------------- 신호에 실을 상태 ----------------
def health_for_hello(lanes_cap=None):
    """agent 후크: '살아 있음' state 에 실을 작은 묶음(gate 가 4000자에서 자름 — 그보다 작게 유지)."""
    h = _rj(VAR / "health.json") or {}
    r = _rj(VAR / "rounds.json") or {}
    sc = _rj(VAR / "selfcheck.json") or {}
    relogin = sorted(k for k, v in (r.get("login") or {}).items() if v.get("state") == "relogin")
    out = {"cpu": h.get("cpu"), "mem": h.get("mem"), "disk": h.get("disk"), "heal": HEAL_VERSION,
           "fail_today": r.get("fail_today", 0) if r.get("day") == _day() else 0,
           "login_ok": sum(1 for v in (r.get("login") or {}).values() if v.get("state") == "ok"),
           "relogin": relogin[:30], "relogin_n": len(relogin),
           "selfcheck": {"day": sc.get("day"), "ok": sc.get("ok"), "bad": sc.get("bad")} if sc else None,
           "throttled": throttled(), "events": (h.get("events") or [])[-5:]}
    if lanes_cap is not None:
        out["lanes_cap"] = lanes_cap
    if r.get("rollback"):
        out["rollback"] = r["rollback"]
    if h.get("snow"):
        out["snow"] = h["snow"][:200]
    return out


# ---------------- 1분 틱 ----------------
def tick(now=None):
    c = cfg()
    now = now or now_utc()
    st = _rj(VAR / "heal_state.json") or {}
    events = (_rj(VAR / "health.json") or {}).get("events") or []
    cpu = cpu_pct(st)

    def ev(s):
        events.append(f"{now.astimezone(KST).strftime('%m-%d %H:%M')} {s}")

    svc = service_check(c)
    if svc.startswith("다시"):
        ev("서비스 " + svc)
    for lane in chrome_hang(c, st):
        ev(f"칸 {lane} Chrome 멈춤 → 그 칸만 다시")
    d = disk_pct()
    snow = None
    if d is not None and d >= float(c["disk_pct"]):
        r = disk_clean(c)
        ev(f"디스크 {d}% → 정리 {r['freed_mb']}MB")
        d2 = disk_pct()
        if d2 is not None and d2 >= float(c["disk_pct"]):
            snow = f"디스크가 정리 뒤에도 {d2}% 예요 — 더 큰 서버로 옮기거나 디스크를 늘려야 해요(Snow 확인 필요)"
        d = d2
    m = mem_pct()
    if throttle_set(c, m):
        ev(f"메모리 {m}% → 새 회차 {c['throttle_min']}분 늦춤")
    try:
        sr = screen_handle()
        if sr:
            ev(f"원격 로그인 화면 요청 {sr['id']} → {sr['state']}")
    except Exception as e:  # noqa: BLE001
        hlog(f"원격 화면 요청 처리 오류 {type(e).__name__}")
    day = _day(now)
    if st.get("selfcheck_day") != day:
        sc = selfcheck(c, now)
        st["selfcheck_day"] = day
        if not sc["ok"]:
            ev("자체 점검 확인 필요: " + ",".join(sc["bad"]))
    h = {"at": now.isoformat(), "cpu": cpu, "mem": m, "disk": d, "service": svc, "events": events[-20:], "snow": snow}
    _wj(VAR / "heal_state.json", st)
    _wj(VAR / "health.json", h)
    return h


# ---------------- [원격 로그인 화면 열기] 요청 처리(root) ----------------
# 에이전트(prime 사용자)가 gate 에서 받은 요청을 VAR/screen_req.json 에 둔다 → 이 함수(root, prime-screen-req.path 또는 1분 틱)가
# prime-screen.sh 를 '해시 모드'로 띄우고(토큰은 서버에 없음 — 해시와 맞는 주소만 열림) 바깥 주소 호스트 이름만 screen_up.json 에 남긴다.
import re as _re
SCREEN_SH = os.environ.get("PRIME_SCREEN_SH", "/opt/prime-collector/kit/prime-screen.sh")


def screen_handle(run=subprocess.run, chown=None):
    req = _rj(VAR / "screen_req.json")
    if not req:
        return None
    done = _rj(VAR / "screen_handled.json") or {}
    if req.get("id") == done.get("id"):
        return None
    rid, store, h = req.get("id"), str(req.get("store") or ""), str(req.get("token_sha256") or "")
    _wj(VAR / "screen_handled.json", {"id": rid, "at": now_utc().isoformat()})
    out = {"id": rid, "state": "failed", "url_host": None, "note": None}
    if not (isinstance(rid, int) and _re.fullmatch(r"[0-9A-Za-z_-]{1,20}", store) and _re.fullmatch(r"[0-9a-f]{64}", h)):
        out["note"] = "요청 모양이 맞지 않음"
    elif float(req.get("expires_ts") or 0) < time.time():
        out.update(state="expired", note="요청 시간이 지남")
    else:
        try:
            r = run([SCREEN_SH, store, "--hash", h], capture_output=True, text=True, timeout=150)
            host = None
            for line in (r.stdout or "").splitlines():
                if line.startswith("url_host="):
                    host = line.split("=", 1)[1].strip()
            if r.returncode == 0 and host and _re.fullmatch(r"[a-z0-9-]{1,63}\.trycloudflare\.com", host):
                out.update(state="open", url_host=host)
                hlog(f"원격 로그인 화면을 열었어요(요청 {rid}, 매장 칸 store-{store}, 30분 뒤 저절로 닫힘)")
            else:
                out["note"] = "원격 화면 주소를 만들지 못함"
        except (OSError, subprocess.TimeoutExpired) as e:
            out["note"] = type(e).__name__
    _wj(VAR / "screen_up.json", out)
    try:
        (chown or shutil.chown)(str(VAR / "screen_up.json"), "prime", "prime")
    except (OSError, LookupError):
        pass
    return out


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "tick"
    if cmd == "tick":
        print(json.dumps(tick(), ensure_ascii=False))
    elif cmd == "selfcheck":
        print(json.dumps(selfcheck(cfg()), ensure_ascii=False))
    elif cmd == "screen":
        print(json.dumps(screen_handle(), ensure_ascii=False))
    elif cmd == "show":
        print(json.dumps(health_for_hello(), ensure_ascii=False))
    else:
        print("사용법: selfheal.py tick | selfcheck | screen | show")


if __name__ == "__main__":
    main()
