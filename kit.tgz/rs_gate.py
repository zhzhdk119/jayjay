# 원격 로그인 화면 문(R-ADV-1120-2306, CLOUD_TEST_2 gate.py 를 서버용으로): 127.0.0.1:8090 에만 열고, 밖과는 cloudflared 가 '나가는' 연결로만 잇는다(들어오는 포트 0).
# - 1회용 주소: /<토큰>/ 아래만 열린다(토큰은 시작할 때 무작위로 1번 만들고 Sandbox 를 닫으면 사라짐). 그 밖은 전부 404.
# - 첫 접속 고정: 처음 원격 화면에 붙은 접속지(IP)만 다시 붙을 수 있다. 동시에 1명만.
# - 키 입력·화면 내용은 기록하지 않는다(접속/끊김 시각과 결과만 gate.log).
import asyncio
import os
import time
from pathlib import Path

from aiohttp import web, WSMsgType

import hashlib  # R-ADV-1120-2325: 해시 모드 — 토큰 파일 대신 token_sha256 이 있으면 경로 토큰의 sha256 이 같을 때만 연다
_TP, _HP = Path("/run/prime-screen/token"), Path("/run/prime-screen/token_sha256")
TOKEN = _TP.read_text().strip() if _TP.exists() else None
TOKEN_SHA = _HP.read_text().strip() if _HP.exists() else None


def tok_ok(tok: str) -> bool:
    if TOKEN is not None:
        return tok == TOKEN
    return bool(TOKEN_SHA) and len(tok) >= 20 and hashlib.sha256(tok.encode()).hexdigest() == TOKEN_SHA
WEB = Path("/usr/share/novnc").resolve()
LOG = Path("/run/prime-screen/gate.log")
STATE = {"locked_ip": None, "active": 0, "denied": 0, "connects": 0}


def log(msg: str) -> None:
    with LOG.open("a") as f:
        f.write(f"{time.strftime('%H:%M:%S')} {msg}\n")


def client_ip(req: web.Request) -> str:
    xff = req.headers.get("cf-connecting-ip") or req.headers.get("x-real-ip") or req.headers.get("x-forwarded-for", "").split(",")[0].strip()
    return xff or (req.remote or "?")


async def ws_proxy(req: web.Request) -> web.StreamResponse:
    ip = client_ip(req)
    if STATE["locked_ip"] and ip != STATE["locked_ip"]:
        STATE["denied"] += 1
        log("ws denied: other ip")
        return web.Response(status=403, text="locked")
    if STATE["active"] >= 1:
        STATE["denied"] += 1
        log("ws denied: already 1 viewer")
        return web.Response(status=409, text="busy")
    ws = web.WebSocketResponse(protocols=("binary",), max_msg_size=0)
    await ws.prepare(req)
    STATE["locked_ip"] = STATE["locked_ip"] or ip
    STATE["active"] += 1
    STATE["connects"] += 1
    log(f"ws open #{STATE['connects']}")
    try:
        reader, writer = await asyncio.open_connection("127.0.0.1", 5900)
    except OSError:
        STATE["active"] -= 1
        await ws.close()
        return ws

    async def tcp_to_ws():
        try:
            while data := await reader.read(65536):
                await ws.send_bytes(data)
        finally:
            await ws.close()

    pump = asyncio.create_task(tcp_to_ws())
    try:
        async for msg in ws:
            if msg.type == WSMsgType.BINARY:
                writer.write(msg.data)
                await writer.drain()
            elif msg.type in (WSMsgType.CLOSE, WSMsgType.ERROR):
                break
    finally:
        pump.cancel()
        writer.close()
        STATE["active"] -= 1
        log("ws close")
    return ws


async def handle(req: web.Request) -> web.StreamResponse:
    tok = req.match_info["tok"]
    tail = req.match_info["tail"]
    if not tok_ok(tok):
        return web.Response(status=404, text="not found")
    if tail in ("websockify", f"{tok}/websockify"):
        return await ws_proxy(req)
    if tail in ("", "/"):
        raise web.HTTPFound(f"/{tok}/vnc.html?path={tok}/websockify&autoconnect=1&resize=scale&reconnect=1")
    p = (WEB / tail).resolve()
    if WEB not in p.parents or not p.is_file():
        return web.Response(status=404, text="not found")
    return web.FileResponse(p, headers={"Cache-Control": "no-store", "Referrer-Policy": "no-referrer",
                                        "X-Robots-Tag": "noindex"})


async def status(req: web.Request) -> web.Response:
    # 127.0.0.1 에서만(점검 스크립트용). 토큰·IP 는 내보내지 않는다.
    if req.remote not in ("127.0.0.1", "::1") or req.headers.get("x-forwarded-for") or req.headers.get("cf-connecting-ip"):
        return web.Response(status=404, text="not found")
    return web.json_response({"locked": bool(STATE["locked_ip"]), "active": STATE["active"],
                              "denied": STATE["denied"], "connects": STATE["connects"]})


async def not_found(req: web.Request) -> web.Response:
    return web.Response(status=404, text="not found")


app = web.Application()
app.router.add_get("/_rs_status", status)
app.router.add_get("/{tok}/{tail:.*}", handle)
app.router.add_get("/{tok}", not_found)
app.router.add_get("/", not_found)
log("gate start")
web.run_app(app, host="127.0.0.1", port=8090, access_log=None, print=None)
