#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Prime 수집 서버 '칸 감시기'(R-ADV-1121-0116). 우분투 22.04/24.04 공통 · 표준 라이브러리만 · 특정 클라우드 전용 코드 0.

하는 일
  ① 칸 수 자동: 메모리(공칭 GB) 보고 정함 — 4GB 2칸 · 8GB 4칸 · 16GB 9칸 · 32GB 19칸 (2040 계획값: (GB×0.8 − 0.6) ÷ 1.3)
     실측 보정: 칸별 메모리 최고치(최근 회차)를 모아 3번 이상이면 p90×1.1 이 계획값보다 크면 칸당 GB 를 올림(= 칸 수 줄임).
     칸 수를 늘리는 쪽 보정은 config "lanes": {"auto_raise": true} 일 때만.
     손으로 고정: env PRIME_LANES=<n> 또는 config "lanes": {"count": n}
  ② 칸마다 따로: 폴더 /var/lib/prime-collector/lanes/lane-<k>/(Chrome 프로필은 그 안 profiles/) · 포트 묶음 9300+k×100 ·
     Chrome 방식 = headless(기본, 창 0) 또는 xvfb(칸마다 자기 화면 :<100+k>) — env PRIME_CHROME_MODE / config "lanes": {"chrome": ...}
  ③ 죽으면 다시 띄움: 칸 프로세스가 끝나면 5→15→60→300초 간격으로 다시(10분 넘게 잘 돌면 간격 처음으로).
     회차 모드(once)는 실패한 칸만 1번 더. 칸이 끝나면 그 칸 프로필을 쓰던 Chrome 이 남지 않게 정리.
  ④ 상태: lanes/status.json(칸별 pid·상태·다시 띄운 수·메모리 최고) → selfheal 하루 점검·'살아 있음'에 실림

  python3 lanesup.py plan                         지금 기계의 칸 계획 1줄(JSON)
  python3 lanesup.py serve -- <명령 …{k}…>         칸 N개를 계속 돌림(죽으면 다시) — 끝 = SIGTERM
  python3 lanesup.py once  -- <명령 …{k}…>         칸 N개 1회차(실패 칸만 1번 더) → 결과 1줄
  명령 안의 {k}=칸 번호 · {n}=칸 수 · {dir}=칸 폴더 · {py}=파이썬 경로

되돌리기: 꾸러미 manifest 에서 "lane_cmd" 를 빼면 에이전트는 예전처럼 entry 를 한 번 실행(칸 감시기 안 씀).
"""
import json
import math
import os
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

LANESUP_VERSION = "0116.1"
VAR = Path(os.environ.get("PRIME_VAR", "/var/lib/prime-collector"))
ETC = Path(os.environ.get("PRIME_ETC", "/etc/prime-collector"))
PROC = Path(os.environ.get("PRIME_PROC", "/proc"))
PORT_BASE = 9300
PORT_BLOCK = 100
DISPLAY_BASE = 100

DEFAULTS = {
    "count": None,             # None = 자동
    "gb_per_lane": 1.3,        # 2040 계획값(실제 사장님 화면 Chrome 1,256MB 실측 근거) — CT2 실측 0.94GB
    "mem_frac": 0.8,
    "os_gb": 0.6,
    "cpu_per_lane": 0.10,      # 코어/칸(실측 0.017~0.082 의 보수값)
    "cpu_frac": 0.7,
    "max": 64,
    "auto_raise": False,       # 실측이 계획보다 작을 때 칸을 늘릴지(기본 안 늘림 = 안전한 쪽)
    "measure_min": 3,          # 실측 보정에 필요한 회차 수
    "chrome": "headless",      # headless | xvfb
    "backoff": [5, 15, 60, 300],
    "healthy_reset_s": 600,
    "once_retries": 1,
    "stop_grace_s": 10,
    "sample_s": 5,
    "done_exit": [],           # serve 모드에서 이 종료 코드면 '할 일 끝'(다시 띄우지 않음) — env PRIME_LANES_DONE_EXIT="0,64"
}


def cfg():
    c = dict(DEFAULTS)
    try:
        c.update((json.loads((ETC / "config.json").read_text(encoding="utf-8")).get("lanes") or {}))
    except (OSError, ValueError, AttributeError):
        pass
    if os.environ.get("PRIME_LANES"):
        c["count"] = int(os.environ["PRIME_LANES"])
    if os.environ.get("PRIME_LANE_GB"):
        c["gb_per_lane"] = float(os.environ["PRIME_LANE_GB"])
    if os.environ.get("PRIME_CHROME_MODE"):
        c["chrome"] = os.environ["PRIME_CHROME_MODE"]
    if os.environ.get("PRIME_LANES_DONE_EXIT"):
        c["done_exit"] = [int(x) for x in os.environ["PRIME_LANES_DONE_EXIT"].split(",") if x.strip()]
    if c["chrome"] not in ("headless", "xvfb"):
        c["chrome"] = "headless"
    return c


def _rj(p, default=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _wj(p, obj):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, default=str), encoding="utf-8")
    os.replace(tmp, p)


def log(msg):
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} [lanes] {msg}"
    print(line, flush=True)
    try:
        (VAR / "lanes").mkdir(parents=True, exist_ok=True)
        with (VAR / "lanes" / "lanes.log").open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


# ---------------- ① 칸 수 ----------------
def mem_total_gb(proc=PROC):
    for line in (Path(proc) / "meminfo").read_text().splitlines():
        if line.startswith("MemTotal:"):
            return int(line.split()[1]) / 1024 / 1024
    return 0.0


def nominal_gb(mem_gb):
    """커널이 보는 MemTotal 은 공칭보다 2~5% 작다(16GB → 15.6). 공칭으로 되돌려 경계값 흔들림을 없앤다."""
    x = mem_gb / 0.97
    std = (1, 2, 4, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512)
    near = min(std, key=lambda g: abs(g - x))
    return near if abs(near - x) <= 0.08 * near else max(1, int(round(x)))


def measured_gb_per_lane(c, stats=None):
    """최근 회차 칸별 메모리 최고치(MB) 목록 → p90×1.1 GB. 표본 부족이면 None."""
    stats = stats if stats is not None else (_rj(VAR / "lanes" / "mem_stats.json") or {}).get("lane_peak_mb", [])
    xs = sorted(float(x) for x in stats if x and float(x) > 0)
    if len(xs) < int(c["measure_min"]):
        return None
    p90 = xs[min(len(xs) - 1, int(math.ceil(0.9 * len(xs))) - 1)]
    return round(p90 / 1024 * 1.1, 3)


def plan(mem_gb=None, vcpu=None, c=None, stats=None):
    c = c or cfg()
    mem_gb = mem_total_gb() if mem_gb is None else mem_gb
    vcpu = vcpu or os.cpu_count() or 1
    nom = nominal_gb(mem_gb)
    gb = float(c["gb_per_lane"])
    basis = "plan"
    meas = measured_gb_per_lane(c, stats)
    if meas is not None and (meas > gb or c.get("auto_raise")):
        gb, basis = max(0.5, meas), "measured"
    by_mem = int((nom * float(c["mem_frac"]) - float(c["os_gb"])) / gb + 1e-9)
    by_cpu = int(vcpu * float(c["cpu_frac"]) / float(c["cpu_per_lane"]) + 1e-9)
    n = max(1, min(by_mem, by_cpu, int(c["max"])))
    if c.get("count"):
        n, basis = max(1, min(int(c["count"]), int(c["max"]))), "fixed"
    return {"lanes": n, "mem_gb": round(mem_gb, 2), "nominal_gb": nom, "vcpu": vcpu, "gb_per_lane": round(gb, 3),
            "by_mem": by_mem, "by_cpu": by_cpu, "basis": basis, "measured_gb": meas, "chrome": c["chrome"]}


# ---------------- ② 칸별 환경 ----------------
def lane_dir(k):
    return VAR / "lanes" / f"lane-{k}"


def chrome_flags(mode):
    base = ["--no-first-run", "--no-default-browser-check", "--disable-dev-shm-usage"]
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        base.append("--no-sandbox")
    return (["--headless"] if mode == "headless" else []) + base   # Chrome 132+ 의 --headless = 새 headless(옛 방식은 별도 프로그램으로 분리)


def ensure_xvfb(disp, run=subprocess.run, popen=subprocess.Popen):
    """칸 화면이 없으면 띄우고 그 프로세스를 돌려줌(감시기가 끝날 때 닫음). 이미 있으면 None."""
    if run(["pgrep", "-f", f"^Xvfb {disp}( |$)"], capture_output=True).returncode == 0:
        return None
    x = popen(["Xvfb", disp, "-screen", "0", "1280x860x24", "-nolisten", "tcp"], stdout=subprocess.DEVNULL,
              stderr=subprocess.DEVNULL, start_new_session=True)
    time.sleep(1.5)
    return x


def lane_env(k, n, base_env=None, c=None):
    c = c or cfg()
    d = lane_dir(k)
    (d / "profiles").mkdir(parents=True, exist_ok=True)
    (d / "outbox").mkdir(parents=True, exist_ok=True)
    env = dict(base_env if base_env is not None else os.environ)
    env.update({"PRIME_LANE": str(k), "PRIME_LANES": str(n), "PRIME_LANE_DIR": str(d),
                "PRIME_PROFILE_ROOT": str(d / "profiles"), "PRIME_LANE_OUTBOX": str(d / "outbox"),
                "PRIME_PORT_BASE": str(PORT_BASE + k * PORT_BLOCK), "PRIME_PORT_BLOCK": str(PORT_BLOCK),
                "PRIME_CHROME_MODE": c["chrome"], "PRIME_CHROME_FLAGS": " ".join(chrome_flags(c["chrome"])),
                "PYTHONUNBUFFERED": "1"})
    if c["chrome"] == "xvfb":
        env["DISPLAY"] = f":{DISPLAY_BASE + k}"
    else:
        env.pop("DISPLAY", None)
    return env


def render(cmd, k, n):
    m = {"k": str(k), "n": str(n), "dir": str(lane_dir(k)), "py": sys.executable}
    return [x.format(**m) for x in cmd]


# ---------------- 프로세스 · 메모리 ----------------
def _procs(proc=None):
    out = {}
    proc = Path(proc or PROC)
    if not proc.is_dir():                 # /proc 없는 곳(윈도우 시험) = 빈 목록
        return out
    for p in proc.iterdir():
        if not p.name.isdigit():
            continue
        try:
            st = (p / "stat").read_text()
            ppid = int(st[st.rindex(")") + 2:].split()[1])
            cmd = (p / "cmdline").read_bytes().replace(b"\0", b" ").decode("utf-8", "replace")
            out[int(p.name)] = (ppid, cmd)
        except (OSError, ValueError):
            continue
    return out


def lane_pids(root_pid, ldir, procs):
    """칸 프로세스 = 칸 본체의 자손 ∪ 명령줄에 칸 폴더가 들어간 것(분리 실행된 Chrome 포함)."""
    kids = {}
    for pid, (ppid, _) in procs.items():
        kids.setdefault(ppid, []).append(pid)
    seen, st = set(), [root_pid] if root_pid else []
    while st:
        x = st.pop()
        if x in seen or x not in procs:
            continue
        seen.add(x)
        st.extend(kids.get(x, []))
    key = str(ldir).rstrip("/") + "/"
    seen.update(pid for pid, (_, cmd) in procs.items() if key in cmd)
    return seen


def mem_mb(pid, proc=PROC):
    """PSS(공유 메모리 나눠 셈) — 못 읽으면 RSS."""
    try:
        for line in (Path(proc) / str(pid) / "smaps_rollup").read_text().splitlines():
            if line.startswith("Pss:"):
                return int(line.split()[1]) / 1024
    except (OSError, ValueError):
        pass
    try:
        return int((Path(proc) / str(pid) / "statm").read_text().split()[1]) * 4096 / 2**20
    except (OSError, ValueError, IndexError):
        return 0.0


def kill_lane_leftovers(ldir, procs=None, kill=os.kill, exclude=()):
    """칸 폴더를 쓰던 프로세스(주로 Chrome)가 칸 본체보다 오래 남으면 정리."""
    procs = procs if procs is not None else _procs()
    key = str(ldir).rstrip("/") + "/"
    hit = [pid for pid, (_, cmd) in procs.items() if key in cmd and pid not in exclude and pid != os.getpid()]
    for sig in (signal.SIGTERM, getattr(signal, "SIGKILL", signal.SIGTERM)):
        for pid in hit:
            try:
                kill(pid, sig)
            except OSError:
                pass
        if sig == signal.SIGTERM and hit:
            time.sleep(2)
    return len(hit)


# ---------------- ③ 감시기 ----------------
class Lane:
    def __init__(self, k):
        self.k, self.p, self.started, self.restarts, self.tries = k, None, 0.0, 0, 0
        self.next_at, self.backoff_i, self.last_exit, self.mem_peak, self.done, self.leftover_killed = 0.0, 0, None, 0.0, False, 0

    def info(self):
        return {"lane": self.k, "pid": self.p.pid if self.p and self.p.poll() is None else None,
                "state": "done" if self.done else ("run" if self.p and self.p.poll() is None else "wait"),
                "restarts": self.restarts, "last_exit": self.last_exit, "mem_peak_mb": round(self.mem_peak),
                "leftover_killed": self.leftover_killed}


class Supervisor:
    def __init__(self, n, cmd, mode="loop", c=None, base_env=None, popen=subprocess.Popen, out=None, deadline=None):
        self.n, self.cmd, self.mode, self.c = n, cmd, mode, c or cfg()
        self.base_env, self.popen, self.deadline = base_env, popen, deadline
        self.out = Path(out) if out else VAR / "lanes"
        self.lanes = [Lane(k) for k in range(n)]
        self.stop_ev = threading.Event()
        self.xvfb = []                     # 이 감시기가 띄운 칸 화면(Xvfb) — 끝날 때 닫음
        self.events = []
        self.t0 = time.time()

    def ev(self, s):
        self.events.append(f"{time.strftime('%H:%M:%S')} {s}")
        self.events = self.events[-50:]
        log(s)

    def start(self, ln):
        env = lane_env(ln.k, self.n, self.base_env, self.c)
        if self.c["chrome"] == "xvfb":
            x = ensure_xvfb(env["DISPLAY"])
            if x is not None:
                self.xvfb.append(x)
        logf = open(lane_dir(ln.k) / "lane.log", "ab")
        try:
            ln.p = self.popen(render(self.cmd, ln.k, self.n), env=env, cwd=str(lane_dir(ln.k)), stdout=logf,
                              stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True)
        finally:
            logf.close()
        ln.started, ln.tries = time.time(), ln.tries + 1

    def _stop_proc(self, ln):
        if not ln.p or ln.p.poll() is not None:
            return
        def sig(kind):
            try:
                if hasattr(os, "killpg"):
                    os.killpg(ln.p.pid, signal.SIGTERM if kind == "term" else signal.SIGKILL)
                else:
                    ln.p.terminate() if kind == "term" else ln.p.kill()
            except OSError:
                pass
        sig("term")
        try:
            ln.p.wait(timeout=float(self.c["stop_grace_s"]))
        except subprocess.TimeoutExpired:
            sig("kill")
            ln.p.wait()

    def poll(self, now=None):
        now = now or time.time()
        for ln in self.lanes:
            if ln.done:
                continue
            if ln.p is None:
                if now >= ln.next_at:
                    self.start(ln)
                continue
            rc = ln.p.poll()
            if rc is None:
                if self.mode == "loop" and ln.backoff_i and now - ln.started >= float(self.c["healthy_reset_s"]):
                    ln.backoff_i = 0
                continue
            ln.last_exit = rc
            ln.leftover_killed += kill_lane_leftovers(lane_dir(ln.k))
            ln.p = None
            if self.mode == "once":
                if rc == 0 or ln.tries > int(self.c["once_retries"]):
                    ln.done = True
                    if rc:
                        self.ev(f"칸 {ln.k} 실패 exit={rc} (다시 {ln.tries - 1}번 뒤 포기)")
                    continue
                ln.restarts += 1
                ln.next_at = now + float(self.c["backoff"][0])
                self.ev(f"칸 {ln.k} 실패 exit={rc} → {self.c['backoff'][0]}초 뒤 그 칸만 다시")
            else:
                if self.stop_ev.is_set() or rc in [int(x) for x in self.c.get("done_exit") or []]:
                    ln.done = True
                    continue
                b = self.c["backoff"][min(ln.backoff_i, len(self.c["backoff"]) - 1)]
                ln.backoff_i += 1
                ln.restarts += 1
                ln.next_at = now + float(b)
                self.ev(f"칸 {ln.k} 끝남 exit={rc} → {b}초 뒤 다시 띄움(누적 {ln.restarts})")

    def sample(self):
        procs = _procs()
        tot = 0.0
        for ln in self.lanes:
            pids = lane_pids(ln.p.pid if ln.p and ln.p.poll() is None else None, lane_dir(ln.k), procs)
            m = sum(mem_mb(p) for p in pids)
            ln.mem_peak = max(ln.mem_peak, m)
            tot += m
        return tot

    def status(self):
        st = {"at": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "version": LANESUP_VERSION, "mode": self.mode, "lanes": self.n,
              "alive": sum(1 for x in self.lanes if x.p and x.p.poll() is None), "chrome": self.c["chrome"],
              "restarts": sum(x.restarts for x in self.lanes), "uptime_s": round(time.time() - self.t0),
              "per_lane": [x.info() for x in self.lanes], "events": self.events[-10:]}
        _wj(self.out / "status.json", st)
        return st

    def record_mem_stats(self):
        p = VAR / "lanes" / "mem_stats.json"
        d = _rj(p) or {}
        xs = (d.get("lane_peak_mb") or []) + [round(x.mem_peak) for x in self.lanes if x.mem_peak > 0]
        _wj(p, {"lane_peak_mb": xs[-200:], "at": time.strftime("%Y-%m-%dT%H:%M:%S%z")})

    def stop_all(self):
        self.stop_ev.set()
        for ln in self.lanes:
            self._stop_proc(ln)
            ln.leftover_killed += kill_lane_leftovers(lane_dir(ln.k))
            ln.done = True
        for x in self.xvfb:                # 0116: xvfb 모드에서 칸 화면이 남던 것(Sandbox xvfb run 에서 발견) 정리
            try:
                x.terminate()
                x.wait(timeout=5)
            except Exception:  # noqa: BLE001
                try:
                    x.kill()
                except Exception:  # noqa: BLE001
                    pass
        self.xvfb = []

    def run(self):
        last_s = 0.0
        try:
            while not self.stop_ev.is_set():
                self.poll()
                if time.time() - last_s >= float(self.c["sample_s"]):
                    self.sample()
                    self.status()
                    last_s = time.time()
                if all(x.done for x in self.lanes):
                    break
                if self.deadline and time.time() >= self.deadline:
                    self.ev("정한 시간이 끝나 칸을 모두 멈춰요")
                    break
                self.stop_ev.wait(1.0)
        finally:
            self.stop_all()
            self.record_mem_stats()
            st = self.status()
        return st


def _split_cmd(argv):
    if "--" in argv:
        return argv[:argv.index("--")], argv[argv.index("--") + 1:]
    return argv, []


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    head, cmd = _split_cmd(argv)
    op = head[0] if head else "plan"
    if op == "plan":
        print(json.dumps(plan(), ensure_ascii=False))
        return 0
    if op in ("serve", "once"):
        if not cmd:
            print("명령이 없어요: lanesup.py serve -- <명령 …{k}…>")
            return 2
        p = plan()
        dur = float(os.environ.get("PRIME_LANES_DURATION_S", "0") or 0)
        sup = Supervisor(p["lanes"], cmd, mode="loop" if op == "serve" else "once",
                         deadline=(time.time() + dur) if dur else None)
        sup.ev(f"칸 {p['lanes']}개 시작 ({p['basis']}, 공칭 {p['nominal_gb']}GB·칸당 {p['gb_per_lane']}GB·Chrome {p['chrome']})")
        signal.signal(signal.SIGTERM, lambda *_: sup.stop_ev.set())
        signal.signal(signal.SIGINT, lambda *_: sup.stop_ev.set())
        st = sup.run()
        print(json.dumps({k: st[k] for k in ("lanes", "alive", "restarts", "chrome", "uptime_s")} |
                         {"failed_lanes": [x["lane"] for x in st["per_lane"] if x["last_exit"] not in (0, None)]},
                         ensure_ascii=False))
        return 0 if op == "serve" or all(x["last_exit"] == 0 for x in st["per_lane"]) else 1
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main())
