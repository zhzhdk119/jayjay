#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Prime 수집 서버 에이전트(R-ADV-1120-2306). 비밀값 0 — 서버가 스스로 만든 Ed25519 키로 서명만 한다.

- 개인 키: /etc/prime-collector/host_key.pem (권한 600, 서버 밖으로 나가지 않음)
- 등록 코드 8글자 = 공개 키 지문(sha256 앞 40비트, base32) — 비밀 아님
- 밖에서 들어오는 접속 0: 이 프로그램이 우리 쪽(gate)으로 나가는 요청만 한다(당겨 오기)
- 하는 일(반복): 살아 있음(hello) → 꾸러미 확인(바뀌었으면 받아 바꿈) → 배정된 칸 → 회차 → 결과 쓰기

  prime-agent run        서비스 본체(systemd)
  prime-agent code       등록 코드 보기
  prime-agent enroll     등록 대기 줄에 공개 키 올리기(설치 때 1번)
  prime-agent status     지금 상태 한 줄
  prime-agent once       회차 1번만(시험용)
  prime-agent replay-test  같은 서명 요청 2번 → 두 번째가 거부되는지(시험용)
"""
import base64
import hashlib
import json
import os
import platform
import secrets
import shutil
import subprocess
import sys
import tarfile
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

AGENT_VERSION = "2306.2+2325+0116+0157"   # R-ADV-1120-2325 저절로 낫기·원격 화면 요청 · R-ADV-1121-0116 칸 감시기 · 0157 replay 재서명
ETC = Path(os.environ.get("PRIME_ETC", "/etc/prime-collector"))
VAR = Path(os.environ.get("PRIME_VAR", "/var/lib/prime-collector"))
KEY = ETC / "host_key.pem"
CONF = ETC / "config.json"
B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"

# R-ADV-1120-2325: 저절로 낫기 후크(selfheal.py 가 없으면 전부 건너뜀 — 2306 동작 그대로)
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import selfheal as _heal
except Exception:  # noqa: BLE001
    _heal = None
# R-ADV-1121-0116: 칸 감시기(lanesup.py 가 없으면 2306 동작 그대로)
try:
    import lanesup as _lanes
except Exception:  # noqa: BLE001
    _lanes = None


def log(msg):
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}"
    print(line, flush=True)
    try:
        VAR.mkdir(parents=True, exist_ok=True)
        with (VAR / "agent.log").open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def conf():
    return json.loads(CONF.read_text(encoding="utf-8"))


# ---------- 키 ----------
def _crypto():
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    return serialization, Ed25519PrivateKey


def ensure_key():
    serialization, Ed = _crypto()
    if not KEY.exists():
        ETC.mkdir(parents=True, exist_ok=True)
        k = Ed.generate()
        pem = k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
        fd = os.open(str(KEY), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(pem)
        log("서명 키를 이 서버 안에서 새로 만들었어요(밖으로 나가지 않음, 권한 600)")
    os.chmod(KEY, 0o600)


def load_key():
    serialization, _ = _crypto()
    k = serialization.load_pem_private_key(KEY.read_bytes(), password=None)
    pub = k.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return k, pub


def ident(pub):
    h = hashlib.sha256(pub).digest()
    bits = int.from_bytes(h[:5], "big")
    code = "".join(B32[(bits >> (5 * i)) & 31] for i in range(7, -1, -1))
    return h.hex(), code


def pretty(code):
    return code[:4] + "-" + code[4:]


# ---------- 서명 요청 ----------
_last_ts = [0]
_call_lock = threading.Lock()   # 요청은 한 번에 하나씩(서명 시각이 늘 커지게 — 되풀이 거부와 맞물림)


def call(op, body=None, timeout=120):
    with _call_lock:
        return _call(op, body, timeout)


def _shared_ts():
    """R-ADV-1121-0157: 러너 gate 모드(runner/host_gate.py)도 같은 키로 서명 → 공유 파일(VAR/sign.last_ts)보다 큰 시각."""
    p = VAR / "sign.last_ts"
    try:
        last = int(p.read_text(encoding="ascii").strip() or 0)
    except (OSError, ValueError):
        last = 0
    ts = max(int(time.time() * 1000), _last_ts[0] + 1, last + 1)
    _last_ts[0] = ts
    try:
        p.write_text(str(ts), encoding="ascii")
    except OSError:
        pass
    return ts


def _call(op, body=None, timeout=120):
    """R-ADV-1121-0157: 'replay' 401(같은 서버의 러너 칸 요청과 엇갈림)이면 새 시각으로 다시 서명해 최대 3번 더."""
    for sign_try in range(4):
        st, j = _call_signed(op, body, timeout)
        if not (st == 401 and (j or {}).get("error") == "replay" and sign_try < 3):
            return st, j
    return st, j


def _call_signed(op, body=None, timeout=120):
    k, pub = load_key()
    host_id, _ = ident(pub)
    data = json.dumps(body or {}, ensure_ascii=False).encode()
    ts = _shared_ts()
    nonce = secrets.token_hex(16)
    msg = f"{op}\n{ts}\n{nonce}\n{hashlib.sha256(data).hexdigest()}".encode()
    sig = base64.b64encode(k.sign(msg)).decode()
    req = urllib.request.Request(conf()["gate_url"], data=data, method="POST", headers={
        "content-type": "application/json", "x-op": op, "x-host": host_id, "x-ts": str(ts), "x-nonce": nonce, "x-sig": sig,
        "user-agent": f"prime-agent/{AGENT_VERSION}"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.status, json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as e:
            try:
                j = json.loads(e.read() or b"{}")
            except ValueError:
                j = {}
            if e.code in (429, 502, 503, 504) and attempt < 3:
                time.sleep(20 * (attempt + 1))
                continue
            return e.code, j
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            if attempt < 3:
                time.sleep(10 * (attempt + 1))
                continue
            return 0, {"error": type(e).__name__}
    return 0, {"error": "retries"}


def machine():
    mem_kb = 0
    for line in Path("/proc/meminfo").read_text().splitlines():
        if line.startswith("MemTotal:"):
            mem_kb = int(line.split()[1])
    mem_gb = round(mem_kb / 1024 / 1024, 1)
    gb_per_lane = float(conf().get("gb_per_lane", 1.3))
    lanes = max(1, int(mem_gb * 0.75 // gb_per_lane))     # 2040 계획값: 메모리 75% / 칸당 1.3GB (8GB → 4칸, 16GB → 9칸)
    if _lanes:                                             # 0116: 공칭 GB 기준(MemTotal 15.6 → 16GB → 9칸) + 실측 보정
        try:
            lanes = _lanes.plan(mem_kb / 1024 / 1024)["lanes"]
        except Exception:  # noqa: BLE001
            pass
    os_name = ""
    try:
        for line in Path("/etc/os-release").read_text().splitlines():
            if line.startswith("PRETTY_NAME="):
                os_name = line.split("=", 1)[1].strip('"')
    except OSError:
        pass
    return {"hostname": platform.node()[:80], "vcpu": os.cpu_count(), "mem_gb": mem_gb, "lanes_cap": lanes, "os": os_name}


def enroll():
    k, pub = load_key()
    host_id, code = ident(pub)
    m = machine()
    body = {"pubkey": base64.b64encode(pub).decode(), "hostname": m["hostname"], "vcpu": m["vcpu"], "mem_gb": m["mem_gb"],
            "os": m["os"], "agent_version": AGENT_VERSION}
    st, j = call("enroll", body)
    if st == 200 and j.get("code8") != code:
        log("등록 코드가 서버 계산과 달라요 — 설치를 다시 해 주세요")
        return st, j
    return st, j


# ---------- 꾸러미 ----------
def current_bundle():
    p = VAR / "bundle" / "current"
    return p.resolve().name if p.exists() else None


def install_bundle(meta):
    ver, want = meta["version"], meta["sha256"]
    st, j = call("bundle_get", {"version": ver}, timeout=300)
    if st != 200:
        log(f"꾸러미 받기 실패 {st} {j.get('error')}")
        return False
    raw = base64.b64decode(j["b64"])
    if hashlib.sha256(raw).hexdigest() != want:
        log("꾸러미 확인값이 달라요 — 바꾸지 않음")
        return False
    root = VAR / "bundle"
    dst = root / ver
    tmp = root / (ver + ".tmp")
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    tgz = root / (ver + ".tgz")
    tgz.write_bytes(raw)
    with tarfile.open(tgz) as t:
        try:
            t.extractall(tmp, filter="data")
        except TypeError:                 # filter 인자가 없는 옛 파이썬(우분투 22.04 초기 3.10) — 경로 검사 후 풀기
            for m in t.getmembers():
                if m.name.startswith(("/", "..")) or "/../" in m.name or m.issym() or m.islnk():
                    raise ValueError(f"꾸러미 안 위험한 경로 {m.name}")
            t.extractall(tmp)
    man = json.loads((tmp / "prime_bundle.json").read_text(encoding="utf-8"))
    venv = VAR / "venv"
    if not (venv / "bin" / "python").exists():
        subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
    reqs = man.get("requirements") or []
    if reqs:
        r = subprocess.run([str(venv / "bin" / "pip"), "install", "-q", *reqs], capture_output=True, text=True)
        if r.returncode:
            log(f"꾸러미 준비(pip) 실패 — 이전 꾸러미 유지: {r.stderr[-300:]}")
            return False
    shutil.rmtree(dst, ignore_errors=True)
    tmp.rename(dst)
    link = root / "current"
    new = root / "current.new"
    if new.is_symlink() or new.exists():
        new.unlink()
    new.symlink_to(dst.name)
    new.replace(link)                     # 원자적 바꿈
    log(f"꾸러미 {ver} 로 바꿨어요(이전은 지우지 않음 — 되돌리기 = 이전 번호를 다시 켬)")
    return True


def sync_bundle():
    st, meta = call("bundle_meta")
    if st != 200 or not meta.get("version"):
        return current_bundle()
    if _heal and _heal.is_bad_bundle(meta["version"]):
        return current_bundle()
    if meta["version"] != current_bundle():
        install_bundle(meta)
    return current_bundle()


# ---------- 회차 ----------
def ensure_display():
    disp = conf().get("display", ":90")
    if subprocess.run(["pgrep", "-f", f"Xvfb {disp}"], capture_output=True).returncode != 0:
        subprocess.Popen(["Xvfb", disp, "-screen", "0", "1280x860x24", "-nolisten", "tcp"],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        time.sleep(2)
    return disp


def run_round(lanes):
    ver = current_bundle()
    if not ver:
        log("꾸러미가 아직 없어요 — 회차 건너뜀")
        return None
    cap = machine()["lanes_cap"]
    use = lanes[:cap]
    if len(lanes) > cap:
        log(f"배정 칸 {len(lanes)} > 이 서버 칸 상한 {cap} — 앞 {cap}칸만")
    run_id = f"{ident(load_key()[1])[1]}-{time.strftime('%Y%m%dT%H%M%S')}"
    bdir = VAR / "bundle" / "current"
    man = json.loads((bdir / "prime_bundle.json").read_text(encoding="utf-8"))
    out = VAR / "runs" / run_id
    out.mkdir(parents=True, exist_ok=True)
    (out / "assign.json").write_text(json.dumps({"run_id": run_id, "lanes": use}, ensure_ascii=False), encoding="utf-8")
    env = dict(os.environ, DISPLAY=ensure_display(), PRIME_RUN_DIR=str(out), PRIME_PROFILE_ROOT=str(VAR / "profiles"))
    t0 = time.time()
    # 회차 중에도 1분마다 '살아 있음'(회차가 10분 넘어도 운영자 화면이 '늦음'으로 바뀌지 않게)
    stop = threading.Event()
    def beat():
        while not stop.wait(60):
            try:
                hello({"phase": "round", "run_id": run_id, "sec": round(time.time() - t0)}, len(use),
                      sum(len((x.get("job") or {}).get("stores", [])) for x in use))
            except Exception:  # noqa: BLE001
                pass
    threading.Thread(target=beat, daemon=True).start()
    if man.get("lane_cmd") and _lanes:
        try:
            return _lane_round(man, bdir, use, run_id, out, env, ver, t0)
        finally:
            stop.set()
    try:
        r = subprocess.run([str(VAR / "venv" / "bin" / "python"), str(bdir / man["entry"]), str(out / "assign.json")],
                           cwd=str(bdir), env=env, capture_output=True, text=True, timeout=int(man.get("timeout_s", 3000)))
    finally:
        stop.set()
    (out / "entry.log").write_text((r.stdout or "")[-20000:] + "\n--\n" + (r.stderr or "")[-20000:], encoding="utf-8")
    res_p = out / "results.json"
    if r.returncode or not res_p.exists():
        log(f"회차 {run_id} 실패 exit={r.returncode}")
        if _heal:
            m = _heal.after_round(ver, False)
            if m:
                log(m)
        return {"run_id": run_id, "ok": False, "sec": round(time.time() - t0, 1)}
    res = json.loads(res_p.read_text(encoding="utf-8"))
    if _heal:
        m = _heal.after_round(ver, True, res.get("per_store"))
        if m:
            log(m)
    rows = [[ident(load_key()[1])[0], run_id, x["lane"], x["store"], x["rows"], x["fail"], x["sec"], ver] for x in res["per_store"]]
    st, j = call("write", {"steps": [{"table": conf().get("result_table", "ops.collector_host_test_results"),
                                      "cols": ["host_id", "run_id", "lane", "store", "rows", "fail", "sec", "bundle_version"],
                                      "rows": rows, "conflict": ["run_id", "lane", "store"]}]})
    log(f"회차 {run_id} 끝: 칸 {len(use)} · 매장 {len(rows)} · 행 {sum(x[4] for x in rows)} · 실패 {sum(x[5] for x in rows)} · 쓰기 {st} {j.get('steps') or j.get('error')}")
    return {"run_id": run_id, "ok": st == 200, "stores": len(rows), "write": j, "sec": round(time.time() - t0, 1)}


def _lane_cmd(man, bdir):
    py = str(VAR / "venv" / "bin" / "python")
    return [x.replace("{bundle}", str(bdir)).replace("{venv_py}", py) for x in man["lane_cmd"]]


def drain_outbox(ver, limit_files=200):
    """칸들이 lanes/lane-<k>/outbox/*.json 에 남긴 결과({"run_id","per_store":[{lane,store,rows,fail,sec}]})를
    서명 요청으로 결과 표에 쓰고, 쓴 파일은 outbox/sent/ 로 옮김(지우지 않음 — 디스크 정리는 저절로 낫기 몫)."""
    host = ident(load_key()[1])[0]
    files = sorted((VAR / "lanes").glob("lane-*/outbox/*.json"))[:limit_files]
    rows, used = [], []
    for f in files:
        try:
            j = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        for x in j.get("per_store") or []:
            rows.append([host, str(j.get("run_id") or f.stem), str(x["lane"]), str(x["store"]), int(x.get("rows", 0)),
                         int(x.get("fail", 0)), float(x.get("sec", 0)), ver])
        used.append(f)
    if not rows:
        return {"files": 0, "rows": 0, "http": None}
    st, j = None, {}
    for i in range(0, len(rows), 2000):
        st, j = call("write", {"steps": [{"table": conf().get("result_table", "ops.collector_host_test_results"),
                                          "cols": ["host_id", "run_id", "lane", "store", "rows", "fail", "sec", "bundle_version"],
                                          "rows": rows[i:i + 2000], "conflict": ["run_id", "lane", "store"]}]})
        if st != 200:
            break
    if st == 200:
        for f in used:
            (f.parent / "sent").mkdir(exist_ok=True)
            f.replace(f.parent / "sent" / f.name)
    return {"files": len(used), "rows": len(rows), "http": st, "stores": rows}


def _lane_round(man, bdir, use, run_id, out, env, ver, t0):
    """0116: 칸마다 따로 프로세스(칸 감시기) — 실패한 칸만 1번 더 → 칸 결과(outbox) 모아 쓰기."""
    env = dict(env, PRIME_RUN_ID=run_id, PRIME_ASSIGN=str(out / "assign.json"))
    sup = _lanes.Supervisor(len(use), _lane_cmd(man, bdir), mode="once", base_env=env, out=out,
                            deadline=time.time() + int(man.get("timeout_s", 3000)))
    sup.ev(f"회차 {run_id}: 칸 {len(use)}개 따로 시작")
    st = sup.run()
    d = drain_outbox(ver)
    per = d.pop("stores", [])
    fail_lanes = [x["lane"] for x in st["per_lane"] if x["last_exit"] not in (0, None)]
    ok = not fail_lanes and d["http"] in (200, None)
    if _heal:
        m = _heal.after_round(ver, ok, [{"lane": r[2], "store": r[3], "rows": r[4], "fail": r[5]} for r in per])
        if m:
            log(m)
    log(f"회차 {run_id} 끝(칸 감시기): 칸 {len(use)} · 다시 띄움 {st['restarts']} · 실패 칸 {fail_lanes} · 매장 {len(per)} · "
        f"행 {sum(r[4] for r in per)} · 쓰기 {d['http']}")
    return {"run_id": run_id, "ok": ok, "stores": len(per), "restarts": st["restarts"], "fail_lanes": fail_lanes,
            "sec": round(time.time() - t0, 1)}


_serve = {"p": None, "ver": None}


def serve_lanes(man, bdir, ver):
    """0116: manifest "lane_mode": "serve" — 칸 감시기를 계속 띄워 둠(죽으면 다시) · 매 틱 칸 결과를 씀."""
    p = _serve["p"]
    if p is not None and p.poll() is None and _serve["ver"] == ver:
        return "run"
    if p is not None and p.poll() is None:            # 꾸러미가 바뀜 → 감시기를 멈추고 새 꾸러미로
        p.terminate()
        try:
            p.wait(timeout=60)
        except subprocess.TimeoutExpired:
            p.kill()
    env = dict(os.environ, PRIME_RUN_DIR=str(VAR / "lanes"), PRIME_PROFILE_ROOT=str(VAR / "profiles"))
    lf = open(VAR / "lanes_sup.out", "ab")
    try:
        _serve["p"] = subprocess.Popen([sys.executable, str(Path(_lanes.__file__)), "serve", "--", *_lane_cmd(man, bdir)],
                                       cwd=str(bdir), env=env, stdout=lf, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                       start_new_session=True)
    finally:
        lf.close()
    _serve["ver"] = ver
    log(f"칸 감시기 시작(꾸러미 {ver})")
    return "start"


def hello(state, lanes_n=None, stores_n=None):
    m = machine()
    if _heal:
        try:
            state = dict(state or {}, health=_heal.health_for_hello(m["lanes_cap"]))
        except Exception:  # noqa: BLE001
            pass
    if _lanes:
        try:
            ls = json.loads((VAR / "lanes" / "status.json").read_text(encoding="utf-8"))
            state = dict(state or {}, lanes_sup={"alive": ls.get("alive"), "lanes": ls.get("lanes"),
                                                 "restarts": ls.get("restarts"), "chrome": ls.get("chrome"), "at": ls.get("at")})
        except (OSError, ValueError):
            pass
    return call("hello", {"lanes": lanes_n if lanes_n is not None else m["lanes_cap"], "stores": stores_n, "vcpu": m["vcpu"],
                          "mem_gb": m["mem_gb"], "bundle_version": current_bundle(), "agent_version": AGENT_VERSION,
                          "state": state})


def screen_watch():
    """R-ADV-1120-2325: 운영자 화면 [원격 로그인 화면 열기] 요청을 30초마다 확인 → screen_req.json(root 서비스가 처리) → 결과 보고."""
    sent = None
    while True:
        try:
            up = json.loads((VAR / "screen_up.json").read_text(encoding="utf-8")) if (VAR / "screen_up.json").exists() else None
            if up and up.get("id") != sent:
                st, _ = call("screen_up", {"id": up["id"], "state": up.get("state"), "url_host": up.get("url_host"), "note": up.get("note")})
                if st == 200:
                    sent = up["id"]
            st, j = call("screen_poll")
            if st == 200 and j.get("id"):
                tmp = VAR / "screen_req.json.tmp"
                tmp.write_text(json.dumps({"id": j["id"], "store": j["store"], "token_sha256": j["token_sha256"],
                                           "expires_ts": j.get("expires_ts")}), encoding="utf-8")
                tmp.replace(VAR / "screen_req.json")
                log(f"원격 로그인 화면 요청 {j['id']} 받음 → 서버가 여는 중")
        except Exception as e:  # noqa: BLE001
            log(f"원격 화면 요청 확인 오류 {type(e).__name__}")
        time.sleep(30)


_screen_started = [False]


def loop(once=False):
    ensure_key()
    if not once and not _screen_started[0] and conf().get("screen_watch", True):
        _screen_started[0] = True
        threading.Thread(target=screen_watch, daemon=True).start()
    _, code = ident(load_key()[1])
    st_file = VAR / "status.json"
    enrolled = False
    last_round = {}
    while True:
        if not enrolled:
            st, j = enroll()
            enrolled = st == 200
            if not enrolled:
                log(f"등록 대기 줄 올리기 실패 {st} {j.get('error')} — 1분 뒤 다시")
        st, j = hello({"phase": "idle"})
        if st == 403 and j.get("error") == "pending":
            st_file.write_text(json.dumps({"state": "pending", "code": pretty(code)}), encoding="utf-8")
            log(f"등록 승인 기다리는 중 — 등록 코드 {pretty(code)}")
            time.sleep(20)
            continue
        if st == 403 and j.get("error") == "disabled":
            st_file.write_text(json.dumps({"state": "disabled", "code": pretty(code)}), encoding="utf-8")
            log("이 서버는 끊겼어요(요청 거부) — 5분 뒤 다시 확인")
            if once:
                return 3
            time.sleep(300)
            continue
        if st != 200:
            log(f"gate 응답 {st} {j.get('error')} — 1분 뒤 다시")
            if once:
                return 2
            time.sleep(60)
            continue
        ver = sync_bundle()
        man = {}
        try:
            man = json.loads((VAR / "bundle" / "current" / "prime_bundle.json").read_text(encoding="utf-8")) if ver else {}
        except (OSError, ValueError):
            man = {}
        if man.get("lane_mode") == "serve" and man.get("lane_cmd") and _lanes and not once:
            serve_lanes(man, VAR / "bundle" / "current", ver)
            d = drain_outbox(ver)
            if d["files"]:
                log(f"칸 결과 {d['files']}파일 · {d['rows']}줄 쓰기 {d['http']}")
            hello({"phase": "serve"})
            time.sleep(int(conf().get("tick_s", 60)))
            continue
        sa, aj = call("assign")
        lanes = aj.get("lanes", []) if sa == 200 else []
        stores = sum(len((x.get("job") or {}).get("stores", [])) for x in lanes)
        every = min([int((x.get("job") or {}).get("every_min", 1440)) for x in lanes] or [1440])
        due = lanes and (once or time.time() - last_round.get("t", 0) >= every * 60)
        st_file.write_text(json.dumps({"state": "enabled", "code": pretty(code), "bundle": ver, "lanes": len(lanes),
                                       "stores": stores}), encoding="utf-8")
        hello({"phase": "round" if due else "idle"}, min(len(lanes), machine()["lanes_cap"]) if lanes else 0, stores)
        if due and _heal and _heal.throttled():
            log("메모리가 높아 새 회차를 잠깐 늦춰요(저절로 낫기)")
            due = False
        if due:
            r = run_round(lanes)
            last_round = {"t": time.time(), "r": r}
            hello({"phase": "idle", "last_round": r}, min(len(lanes), machine()["lanes_cap"]), stores)
            if once:
                return 0 if r and r.get("ok") else 1
        if once:
            return 0
        time.sleep(int(conf().get("tick_s", 60)))


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "run"
    if cmd == "code":
        ensure_key()
        print(pretty(ident(load_key()[1])[1]))
    elif cmd == "enroll":
        ensure_key()
        st, j = enroll()
        print(json.dumps({"http": st, "state": j.get("state"), "error": j.get("error")}))
        sys.exit(0 if st == 200 else 1)
    elif cmd == "status":
        st, j = hello({"phase": "status"})
        print(json.dumps({"http": st, "state": j.get("state") or j.get("error"), "bundle": current_bundle(), "machine": machine()},
                         ensure_ascii=False))
    elif cmd == "once":
        sys.exit(loop(once=True))
    elif cmd == "replay-test":
        # 같은 서명 요청을 그대로 2번 보냄 → 두 번째는 replay 로 거부돼야 함
        k, pub = load_key()
        host_id, _ = ident(pub)
        data = b"{}"
        ts = int(time.time() * 1000)
        nonce = secrets.token_hex(16)
        sig = base64.b64encode(k.sign(f"bundle_meta\n{ts}\n{nonce}\n{hashlib.sha256(data).hexdigest()}".encode())).decode()
        h = {"content-type": "application/json", "x-op": "bundle_meta", "x-host": host_id, "x-ts": str(ts), "x-nonce": nonce, "x-sig": sig}
        out = []
        for _ in range(2):
            try:
                with urllib.request.urlopen(urllib.request.Request(conf()["gate_url"], data=data, method="POST", headers=h), timeout=60) as r:
                    out.append(r.status)
            except urllib.error.HTTPError as e:
                out.append(f"{e.code}:{json.loads(e.read() or b'{}').get('error')}")
        # 서명을 1글자 바꾼 요청
        bad = dict(h, **{"x-ts": str(ts + 5), "x-sig": sig[:-4] + ("AAAA" if not sig.endswith("AAAA") else "BBBB")})
        try:
            urllib.request.urlopen(urllib.request.Request(conf()["gate_url"], data=data, method="POST", headers=bad), timeout=60)
            out.append(200)
        except urllib.error.HTTPError as e:
            out.append(f"{e.code}:{json.loads(e.read() or b'{}').get('error')}")
        print(json.dumps({"first": out[0], "replay": out[1], "forged": out[2]}))
    else:
        while True:
            try:
                loop()
            except Exception as e:  # noqa: BLE001
                log(f"에이전트 오류 {type(e).__name__}: {str(e)[:200]} — 1분 뒤 다시")
                time.sleep(60)


if __name__ == "__main__":
    main()
