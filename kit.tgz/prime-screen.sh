#!/bin/bash
# 원격 로그인 화면(R-ADV-1120-2306 P0-4). 사장님(또는 Snow)이 브라우저 SSH 에서 직접 실행:  prime screen <매장번호>
# - 서버 안 Chrome(그 매장 전용 프로필)을 띄우고, 1회용 주소를 이 터미널에만 보여 줘요(파일 저장 0, AI 는 보지 않음).
# - 들어오는 포트 0: 화면 문(127.0.0.1:8090) ↔ cloudflared 가 밖으로 나가는 연결로만 이어요.
# - 처음 연 접속지만 붙을 수 있고, 30분 뒤(또는 prime screen stop) 저절로 닫혀요. 로그인 상태는 매장 프로필에 남아 수집에 쓰여요.
set -euo pipefail
D=/run/prime-screen
VAR=/var/lib/prime-collector
MIN=${PRIME_SCREEN_MIN:-30}
stop_all() {
  # 원격 화면용 프로세스만(수집 회차의 Xvfb :90·Chrome 은 건드리지 않음)
  # google-chrome 래퍼는 exec -a "$0" 로 바뀌어 이름이 /usr/bin/google-chrome 이 됨 → 앞 고정(^) 없이 화면 시작 파일로만 찾음
  pkill -u prime -f "/opt/prime-collector/kit/[s]tart[.]html" 2>/dev/null || true
  pkill -u prime -f "^cloudflared tunnel --no-autoupdate --url http://127.0.0.1:8090" 2>/dev/null || true
  pkill -u prime -f "^python3 /opt/prime-collector/kit/rs_gate.py" 2>/dev/null || true
  pkill -u prime -f "^x11vnc -display :50" 2>/dev/null || true
  pkill -u prime -x openbox 2>/dev/null || true
  pkill -u prime -f "^Xvfb :50" 2>/dev/null || true
  for i in 1 2 3 4 5; do pgrep -u prime -f "/opt/prime-collector/kit/[s]tart[.]html" >/dev/null || break; sleep 1; done
  pkill -9 -u prime -f "/opt/prime-collector/kit/[s]tart[.]html" 2>/dev/null || true
  if [ -f $D/watch ]; then kill "$(cat $D/watch)" 2>/dev/null || true; fi
  rm -f $D/token $D/token_sha256 $D/pids $D/watch
}
if [ "${1:-}" = "stop" ]; then stop_all; echo "원격 화면을 닫았어요."; exit 0; fi
STORE=${1:-}
[[ "$STORE" =~ ^[0-9A-Za-z_-]{1,20}$ ]] || { echo "사용법: prime screen <매장번호>   (닫기: prime screen stop)"; exit 1; }
SELFTEST=${2:-}
HASH=""   # R-ADV-1120-2325: --hash <sha256> = 토큰은 Snow 브라우저에만 · 서버는 해시만 받아 맞는 주소만 열고 바깥 호스트 이름만 출력
if [ "$SELFTEST" = "--hash" ]; then HASH=${3:-}; [[ "$HASH" =~ ^[0-9a-f]{64}$ ]] || { echo "해시 모양이 아니에요"; exit 1; }; SELFTEST=""; fi
stop_all
mkdir -p $D && chown prime:prime $D && chmod 700 $D
PROF=$VAR/profiles/store-$STORE
install -d -o prime -g prime -m 700 "$VAR/profiles" "$PROF"
if [ -n "$HASH" ]; then
  echo "$HASH" > $D/token_sha256; chown prime:prime $D/token_sha256; chmod 600 $D/token_sha256; TOKEN=""
else
  head -c 24 /dev/urandom | base64 | tr '+/' '-_' | tr -d '=\n' > $D/token
  chown prime:prime $D/token && chmod 600 $D/token
  TOKEN=$(cat $D/token)
fi
as_prime() { sudo -u prime -H env DISPLAY=:50 "$@"; }
pids=()
as_prime setsid Xvfb :50 -screen 0 1280x860x24 -nolisten tcp </dev/null >$D/xvfb.log 2>&1 & pids+=($!)
sleep 2
as_prime setsid openbox </dev/null >/dev/null 2>&1 & pids+=($!)
as_prime setsid x11vnc -display :50 -localhost -rfbport 5900 -forever -shared -quiet -noxdamage -nopw </dev/null >$D/x11vnc.log 2>&1 & pids+=($!)
as_prime setsid google-chrome --user-data-dir="$PROF" --no-first-run --no-default-browser-check --password-store=basic --lang=ko-KR \
  --window-position=0,0 --window-size=1280,860 "file:///opt/prime-collector/kit/start.html" </dev/null >$D/chrome.log 2>&1 & pids+=($!)
as_prime setsid python3 /opt/prime-collector/kit/rs_gate.py </dev/null >$D/gate.out 2>&1 & pids+=($!)
as_prime setsid cloudflared tunnel --no-autoupdate --url http://127.0.0.1:8090 </dev/null >$D/cf.log 2>&1 & pids+=($!)

URL=""
echo "원격 화면을 준비하고 있어요(30초~1분)..."
for i in $(seq 1 90); do
  URL=$(grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' $D/cf.log | head -1 || true)
  # 주소가 나와도 터널 연결이 등록된 뒤에 보여 줌(너무 일찍 열면 주소 찾기 실패가 잠시 남을 수 있음)
  [ -n "$URL" ] && grep -q "Registered tunnel connection" $D/cf.log && break; sleep 1
done
[ -n "$URL" ] || { echo "원격 화면 주소를 만들지 못했어요(cloudflared). 잠시 뒤 다시 해 주세요."; stop_all; exit 1; }
sleep 10
# 30분 뒤 자동 닫기(이 감시 프로세스 번호만 기록 — 주소·토큰은 파일에 쓰지 않음)
setsid bash -c "sleep $((MIN*60)); /opt/prime-collector/kit/prime-screen.sh stop >/dev/null 2>&1" </dev/null >/dev/null 2>&1 &
echo $! > $D/watch
if [ -n "$HASH" ]; then echo "url_host=${URL#https://}"; exit 0; fi
FULL="$URL/$TOKEN/vnc.html?path=$TOKEN/websockify&autoconnect=1&resize=scale&reconnect=1"
if [ "$SELFTEST" = "--selftest" ]; then
  # 시험용: 주소는 출력하지 않고, 이 서버 안에서 바깥 주소로 열어 본 응답 코드만
  for i in $(seq 1 36); do c=$(curl -s -m 10 -o /dev/null -w '%{http_code}' "$URL/$TOKEN/vnc.html" || true); [ "$c" = 200 ] && break; sleep 5; done
  echo "selftest url=hidden token_page=$c no_token=$(curl -s -o /dev/null -w '%{http_code}' "$URL/") wrong_token=$(curl -s -o /dev/null -w '%{http_code}' "$URL/wrongtoken/vnc.html") auto_close_min=$MIN"
  exit 0
fi
echo
echo "==== 아래 주소를 사장님 PC 의 Chrome 에서 여세요. 다른 사람에게 보내지 마세요 ===="
echo "$FULL"
echo "==== 처음 연 브라우저만 붙을 수 있어요. ${MIN}분 뒤 저절로 닫혀요(바로 닫기: prime screen stop) ===="
